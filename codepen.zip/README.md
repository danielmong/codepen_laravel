# Installation Guide

## 1.create database
### - install MySql.
### - create empty database "codepen"
### - migrate using command ( php artisan migrate )

## 2.start server
### - run project using command ( php artisan serve )