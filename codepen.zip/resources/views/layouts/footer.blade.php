<div class="bg-white h-10 flex items-center justify-center">
    <span>@ Copyright 2024</span>
</div>